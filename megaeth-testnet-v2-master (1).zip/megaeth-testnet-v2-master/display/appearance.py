ASCII_ART = """

Velhust Automation MegaEth GTE

"""
CREDIT = """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🧑‍💻 Script được tạo bởi 0xVelhust - https://x.com/0xVelhust

🌐 GitHub            : https://github.com/velhusteth
💬 Join Telegram     : https://t.me/velhustdev
🔗 Twitter           : https://x.com/0xVelhust
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
